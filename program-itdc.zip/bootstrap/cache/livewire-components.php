<?php return array (
  'category-edit-form' => 'App\\Http\\Livewire\\CategoryEditForm',
  'custom-field-set-default-values-for-model' => 'App\\Http\\Livewire\\CustomFieldSetDefaultValuesForModel',
  'importer' => 'App\\Http\\Livewire\\Importer',
  'login-form' => 'App\\Http\\Livewire\\LoginForm',
  'slack-settings-form' => 'App\\Http\\Livewire\\SlackSettingsForm',
);