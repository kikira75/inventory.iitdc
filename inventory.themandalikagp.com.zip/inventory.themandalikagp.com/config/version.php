<?php
return array (
  'app_version' => 'v6.3.1',
  'full_app_version' => 'v6.3.1 - build 12672-g00cea3eb3',
  'build_version' => '12672',
  'prerelease_version' => '',
  'hash_version' => 'g00cea3eb3',
  'full_hash' => 'v6.3.1-180-g00cea3eb3',
  'branch' => 'master',
);